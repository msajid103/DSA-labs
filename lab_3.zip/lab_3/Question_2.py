import numpy as np
students = int(input('Enter total number of students :'))
subjects = int(input('Enter total number of subjects : '))
array = np.empty( shape = (students,subjects) ,dtype='int')
for st in range(students):
    for sb in range(subjects):
        array[st][sb] = int(input(f'Enter number of Roll No._{st+1} in subject_{sb+1} :'))

def highMarks_a(array):
    for col in range(subjects):
        high = 0
        ind = 0
        for row in range(students):
            if high < array[row][col]:
                high = array[row][col]
                ind = row
        print(f'Roll No.{ind+1} has highest marks({high}) in subject_{col+1}')

def highMarks_b(array):
    for row in range(students):
        high = 0
        ind = 0
        for col in range(subjects):
            if high < array[row][col]:
                high = array[row][col]
                ind = col
        print(f'Roll No.{row+1} has highest marks({high}) in subject_{ind+1}')

def lowest_c(array):
    for col in range(subjects):
        low = 1000
        ind = 0
        for row in range(students):
            if low > array[row][col]:
                low = array[row][col]
                ind = row
        print(f'Roll No.{ind+1} has lowest marks({low}) in subject_{col+1}')

def lowest_d(array):
    for row in range(students):
        low = 1000
        ind = 0
        for col in range(subjects):
            if low > array[row][col]:
                low = array[row][col]
                ind = col
        print(f'Roll No.{row+1} has lowest marks({low}) in subject_{ind+1}')

def averag_e(array): 
    for row in range(students):
        sum = 0
        for col in range(subjects):
            sum +=  array[row][col]       
        print(f'Average marks of Roll No.{row+1} = {sum/subjects}')
def highest_averag_f(array):
    ave = 0
    roll_n = 0
    for row in range(students):
        sum = 0
        for col in range(subjects):
            sum +=  array[row][col]
        if ave < sum/subjects:
            ave = sum/subjects
            roll_n = row
    print(f'From all class Roll No.{roll_n+1} has highest Average marks({ave})')
def lowest_averag_g(array):
    ave = 10000
    roll_n = 0
    for row in range(students):
        sum = 0
        for col in range(subjects):
            sum +=  array[row][col]
        if ave > sum/subjects:
            ave = sum/subjects
            roll_n = row
    print(f'From all class Roll No.{roll_n+1} has lowest Average marks({ave})')

def total_marks_h(array): 
    for row in range(students):
        sum = 0
        for col in range(subjects):
            sum +=  array[row][col]       
        print(f'Total marks of Roll No.{row+1} = {sum}')
print('___________')
highMarks_a(array)
print('___________')
highMarks_b(array)
print('___________')
lowest_c(array)
print('___________')
lowest_d(array)
print('___________')
averag_e(array)
print('___________')
highest_averag_f(array)
print('___________')
lowest_averag_g(array)
print('___________')
total_marks_h(array)



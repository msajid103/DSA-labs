
def putValue(array, user, val):
    print(user)
    row = int(input("Enter row number"))
    col = int(input("Enter colum number"))
    if row > 3 or col > 3:
        print ("Enter correct Number")
        putValue(array, user, val)
    if array[row-1][col-1] == '' and array[row-1][col-1] != val:
        array[row-1][col-1] = val
        print()
        print(array[0][0], '    ||   ', array[0][1], '    ||   ', array[0][2])
        print('___________________________')
        print(array[1][0], '    ||    ', array[1][1], '   ||   ', array[1][2])
        print('___________________________')
        print(array[2][0], '    ||    ', array[2][1], '   ||   ', array[2][2])
        print('___________________________')
        print()
    else:
        print('Enter any other location')
        putValue(array, user, val)

def check(array):
    colunms = list(zip(*array))
    for i in range(2):
        if array[i].count('X') == 3 or array[i].count('O') == 3 or colunms[i].count('X') == 3 or colunms[i].count('O') == 3:
            return True  
        elif array[0][0] == array[1][1] and array[1][1] == array[2][2] and array[0][0] != '' and array[1][1] != '' and array[2][2] != '':
            return True 
        elif array[0][2] == array[1][1] and array[1][1] == array[2][0] and array[0][2] != '' and array[1][1] != '' and array[2][0] != '':
            return True      

def game(array):
    print()
    print(array[0][0], '    ||   ', array[0][1], '    ||   ', array[0][2])
    print('___________________________')
    print(array[1][0], '    ||    ', array[1][1], '   ||   ', array[1][2])
    print('___________________________')
    print(array[2][0], '    ||    ', array[2][1], '   ||   ', array[2][2])
    print('___________________________')
    print()
    i = 0
    while True:          
        putValue(array, 'User_1', 'X')
        if check(array):
            return "User_1 win the game"
        i += 1 
        if i == 5:
            rest = input("Game Tie || For restart Press any key : " )
            if rest != 'sajid1234':
                array = [['', '', ''],
                        ['', '', ''],
                        ['', '', '']]
                game(array)            
        putValue(array, 'User_2', 'O')
        if check(array):
            return "User_2 win the game"
        
array = [['', '', ''],
         ['', '', ''],
         ['', '', '']]

print(game(array))

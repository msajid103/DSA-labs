import numpy as np
n_valu = int(input('Enter nth value : '))
array1 = np.zeros( shape = (n_valu,n_valu) ,dtype='int')
array2 = np.zeros( shape = (n_valu,n_valu) ,dtype='int')
for i in range(n_valu):
    for j in range(n_valu):
        value = int(input(f'Enter value in matric_1 at ({i,j}) idex : '))
        array1[i][j] = value
for i in range(n_valu):
    for j in range(n_valu):
        value = int(input(f'Enter value in matric_2 at ({i,j}) index: '))
        array2[i][j] = value

def sum(array1,array2):
    print('Sum')
    sum_array = np.zeros( shape = (n_valu,n_valu) ,dtype='int')
    for i in range(n_valu):
        for j in range(n_valu):
            sum_array[i][j] = array1[i][j] + array2[i][j]
    return sum_array

def multiply(array1,array2):
    print('Multiply')
    multi_array = np.zeros( shape = (n_valu,n_valu) ,dtype='int')
    for i in range(n_valu):
        for j in range(n_valu):
            sum = 0
            for k in range(n_valu):
             sum += array1[i][k]*array2[k][j]
            multi_array[i][j] = sum
    return multi_array
def LeftDiag(array1,array2):
    sum = np.zeros( shape = (n_valu,n_valu) ,dtype='int')
    print("Sum Of Left Diagonals ")
    for i in range (n_valu):
        sum[i][i] = array1[i][i] + array2[i][i]
    return sum
def RightDiag(array1,array2):
    sum = np.zeros( shape = (n_valu,n_valu) ,dtype='int')
    print("Sum Of Right Diagonals ")
    for i in range (1,n_valu+1):
        sum[i-1][-i] = array1[i-1][-i] + array2[i-1][-i]
    return sum

def average(array1,array2):
    print('Average')
    ave_array = np.zeros( shape = (n_valu,n_valu) ,dtype='float')
    for i in range(n_valu):
        for j in range(n_valu):
            ave_array[i][j] = (array1[i][j] + array2[i][j])/2
    return ave_array


print(sum(array1,array2))
print(multiply(array1,array2))
print(LeftDiag(array1,array2))
print(RightDiag(array1,array2))
print(average(array1,array2))




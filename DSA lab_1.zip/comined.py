
def convert(keys):
    for i in range(len(keys)):
        print(keys[i],end="")
convert([45,98,9])
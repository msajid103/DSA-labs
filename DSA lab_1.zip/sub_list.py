def slice(lst):
    new = []
    for i in range(1,len(lst)+1):
        new.append(lst[0:i])
    return new

lst = [1,2,3,4]
main = [[]]
for i in range(len(lst)):
    main += slice(lst[i:])

print(main)
def change_nth(lst):
    for i in range(0,len(lst),2):
        lst[i],lst[i+1] = lst[i+1] , lst[i]


lst = [10,20,30,40,50,60] 
change_nth(lst)

print(lst)
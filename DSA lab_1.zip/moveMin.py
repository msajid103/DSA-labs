def moveMin(index, list):
    mini = list[index]
    minIndex = index
    for i in range(index + 1,len(list)):
        if  mini >= list[i]:
            mini = list[i]
            minIndex = i
    list[index], list[minIndex] = list[minIndex] ,   list[index]
 
list = [23,5,7,8,2,67,1]
for i in range(len(list)):
    moveMin(i,list)
print(list)
def unique(list):
    i = -1
    while i <= len(list):
        for j in range(i+1,len(list)-1):
            # print(len(list),j)
            if list[i] == list[j]:
                list.pop(j)
        i += 1
 
 
lst = [10,15,20,10,30,35,20,3,3]  
unique(lst)
print(lst)
        



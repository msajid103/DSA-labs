list1= [10,20,30,40,50]
list2= [30,40,60,70]
ne = []
for i in range(len(list1)):
    if list1[i] in list2:
        ne.append(list1[i])

print(ne)
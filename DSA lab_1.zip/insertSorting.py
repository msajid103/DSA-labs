def insert(values,j):   
    while values[j] < values[j-1] and j >= 0:
        values[j], values[j-1] = values[j-1] , values[j]
        j = j-1

def sort(list):
    for i in range(1,len(list)):
        insert(list,i)
      
list = [1,3,5,2,9,10,6]
sort(list)
print(list)


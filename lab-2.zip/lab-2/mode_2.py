def mode(lst):
    mode = []
    count = 1
    temp = 1
    for i in range(len(lst)):
        for j in range(i+1, len(lst)):
            if lst[i] == lst[j]:
                temp += 1
        if temp > count:
            count = temp
            mode.clear()
            mode.append(lst[i])
            temp = 1
        elif temp == count and count != 1:
            mode.append(lst[i])
            temp = 1
    if mode == []:
        print('No Mode')
    else:
        print(mode) 
lst = [4,6,4,2,3,2,1]
mode(lst)

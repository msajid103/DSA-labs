def leader(lst):
    flag = True
    leader = []
    for i in range(len(lst)-1):
        for j in range(i+1,len(lst)):
            if lst[i] < lst[j]:
                flag = False                    
        if flag:
            leader.append(lst[i])
        flag = True
    return leader   


    
lst = [1,5,4,2,3,1]
print(leader(lst))
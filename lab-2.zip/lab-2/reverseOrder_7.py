def reverOrder(lst):
    if len(lst) == 1:
        print (lst[0])
    else:
        print(lst[-1])
        return reverOrder(lst[0:len(lst)-1])


lst = [3,1,2,0]
reverOrder(lst)

def minOfList(lst):
    if len(lst) == 1:
        return lst[0]
    else:
        if lst[0] < minOfList(lst[1:]):
            return lst[0]                 
        return minOfList(lst[1:])

lst = [2,3,9,1,10,44]
print( minOfList(lst))
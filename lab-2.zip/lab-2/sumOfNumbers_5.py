def sumOFnumber(n):
    if n == 0:
        return 0
    else:
        return n+sumOFnumber(n-1)

n = int(input('Write nth number: '))

print(sumOFnumber(n))
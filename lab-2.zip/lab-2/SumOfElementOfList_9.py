def sumOfList(lst): 
    if len(lst) == 1:
        return lst[0]
    else:        
        return lst[0]+sumOfList(lst[1:])


lst = [1,2,3,1,2]
print(sumOfList(lst))

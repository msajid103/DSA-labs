def maxi(lst):
    pair = 0
    max = 0
    for i in range(len(lst)-1):
        for j in range(i+1,len(lst)):
            difer = lst[i] - lst[j]
            if difer < 0 :
                difer *= -1
            if difer > max:
                max = difer
                pair = lst[i],lst[j]
    return 'Max pair',pair,'and thier difference', max
def mini(lst):
    pair = 0
    mini = 1000
    for i in range(len(lst)-1):
        for j in range(i+1,len(lst)):
            difer = lst[i] - lst[j]
            if difer < 0 :
                difer *= -1
            if difer < mini:
                mini = difer
                pair = lst[i],lst[j]
    return 'Mini pair = ',pair,'and thier difference = ', mini

lst = [2,10,4,5,11,3]

print(maxi(lst))
print(mini(lst))

            
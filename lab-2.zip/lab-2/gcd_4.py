def gcd(a,b):
    if a%b == 0:
        return b
    else:
        return gcd(b,a%b)

def rel_prime(n):
    total = 0
    prime = 0
    for i in range(1,n):
        for j in range(i+1,n+1):
            if gcd(i,j) == 1:
                prime += 1
            total+=1
            # print((i,j) , end=',')
            
    return 'Probility = ', prime/total
n = int(input('Write nth number: '))
print(rel_prime(n))
def ElementsOfList(lst):
    if len(lst) == 1:
        print (lst[0])
    else:   
        print(lst[0])                   
        return ElementsOfList(lst[1:])

lst = [2,3,1,2]

ElementsOfList(lst)